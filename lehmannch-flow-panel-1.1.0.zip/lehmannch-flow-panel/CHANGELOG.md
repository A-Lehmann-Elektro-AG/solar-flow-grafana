# Changelog

## 1.1.0 - Additional Source 

Following changes were made in this release:
1. Ability to add another energy source
2. Measurement unit dropdown
